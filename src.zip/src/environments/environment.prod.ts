export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyARXWcFqLBbsN7pohKZ8j8a7Xe_asT8ZVI",
    authDomain: "oneclickdilevryapp.firebaseapp.com",
    projectId: "oneclickdilevryapp",
    storageBucket: "oneclickdilevryapp.appspot.com",
    messagingSenderId: "795137448607",
    appId: "1:795137448607:web:5fd4768c6461b4c80b60aa",
    measurementId: "G-D9E3D79503"
  }
};
